from test_package import *

print(module_a.variable_a)
print(module_b.variable_b)
