variable_a = "a 모듈의 변수"
