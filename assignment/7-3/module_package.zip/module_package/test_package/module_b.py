variable_b = "b 모듈의 변수"
