import test_package.module_a as a
import test_package.module_b as b

print(a.variable_a)
print(b.variable_b)
