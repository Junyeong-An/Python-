print("# 모듈의 __name__ 출력하기")
print(__name__)
print()
